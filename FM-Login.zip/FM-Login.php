<?php
/*
Plugin Name: FM - Login
Description: FM - Login
Version: 1.0.0
Author: Farhan Munim
Author URI: https://farhan.app/
*/

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
  die();
}

function redirect_wp_login() {
    // If user goes onto default login page/URL...
    if ( ! is_user_logged_in() && strpos( $_SERVER['REQUEST_URI'], '/wp-login.php' ) !== false ) {
        // ...then redirect to custom login page
        wp_redirect( home_url( '/login' ) );
        exit;
    }
}
add_action( 'init', 'redirect_wp_login' );

// Once log out button is clicked, re-direct user to homepage
function auto_redirect_after_logout(){
  wp_safe_redirect( home_url() );
  exit;
}
add_action('wp_logout','auto_redirect_after_logout');